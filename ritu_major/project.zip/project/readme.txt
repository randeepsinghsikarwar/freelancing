->open and run all cells of dataset_1 and dataset_2 .ipynb files. 
this will create 4 models, 2 for each dataset, 1 classification and 1 regression for each dataset as a .pkl file. 

->open terminal and execute "python app.py" command to start the flask app. 

note! majordb is the database that contains the tables. 
