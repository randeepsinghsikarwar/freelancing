@app.route('/reg', methods=["POST"])
# def classify():
#     species = request.form.get('Species')
#     country = request.form.get('Country.of.Origin')
#     continent = request.form.get('Continent.of.Origin')
#     processing = request.form.get('Processing.Method')
#     harvest_year = int(request.form.get('Harvest.Year'))
#     aroma = float(request.form.get('Aroma'))
#     flavor = float(request.form.get('Flavor'))
#     acidity = float(request.form.get('Acidity'))
#     uniformity = float(request.form.get('Uniformity'))
#     moisture = float(request.form.get('Moisture'))
#     balance = float(request.form.get('Balance'))
#     clean = float(request.form.get('Clean.Cup'))

#     species_encoded = species_mapping.get(species) 
#     continent_encoded = continent_mapping.get(continent)
#     country_encoded = country_mapping.get(country)
#     processing_encoded = processing_mapping.get(processing)

#     features = np.array([[species_encoded, continent_encoded, harvest_year, aroma, flavor, acidity, uniformity, processing_encoded, country_encoded, moisture, balance, clean]])

#     predict = regression_model.predict(features)
#     return render_template("d1m2.html", pred_txt="Predicted value is: {}".format(predict[0]))
