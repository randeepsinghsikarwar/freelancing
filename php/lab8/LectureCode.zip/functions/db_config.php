<?php
const HOST = '127.0.0.1';
const DB = 'comp2002';
const USER = 'root';
const PASS = '';

const DSN = 'mysql:host=' . HOST . ';dbname=' . DB;

const FETCH_MODE = PDO::FETCH_BOTH;
//define('HOST', '127.0.0.1');