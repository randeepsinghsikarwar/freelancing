<?php
const FUNCTIONS_DIR = './functions/';