import "./App.css";
// import QuoteFetcher from "./QuoteFetcher";
// import Counter from "./counter";

function App() {
  return (
    <>
      {/* <Counter /> */}
      {/* <QuoteFetcher /> */}
    </>
  );
}

export default App;
