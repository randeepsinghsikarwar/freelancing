import { useState, useEffect } from "react";

export default function Counter() {
  const [count, setCount] = useState(0);
  const [username, setUsername] = useState("");
  //   UseEffect is used to run code at certian times and not all the times
  useEffect(() => console.log("MY EFFECT WAS CALLED"), [count]);
  const handleUsername = (evt) => {
    setUsername(evt.target.value);
  };
  return (
    <div>
      <h1>{count}</h1>
      <button onClick={() => setCount((prevCount) => prevCount + 1)}>+</button>
      <p>username: {username}</p>
      <input
        type="text"
        name="username"
        id="username"
        value={username}
        onChange={handleUsername}
      />
    </div>
  );
}
