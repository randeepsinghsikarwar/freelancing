import { Link } from "react-router-dom";
export default function HomePage() {
  return (
    <div>
      <Link to={"/createUser"}>
        <button>Create User</button>
      </Link>
      <Link to={"/loginUser"}>
        <button>Login</button>
      </Link>
    </div>
  );
}
