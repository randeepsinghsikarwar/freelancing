import { useState } from "react";
// import { useNavigate } from "react-router-dom";
import axios from "axios";
export default function LoginUser() {
  //   const navigate = useNavigate();
  const [user, setUser] = useState({
    username: "",
    password: "",
  });
  //   const [users, setUsers] = useState([]);
  const [postResponse, setPostResponse] = useState("");

  const handleOnChange = (evt) => {
    const { name, value } = evt.target;
    setUser((prevUser) => {
      return { ...prevUser, [name]: value };
    });
  };

  //   const addToUsers = (user) => {
  //     setUsers((prevUsers) => {
  //       return [...prevUsers, { ...user }];
  //     });
  //   };

  const handlePostUser = async (user) => {
    const postUser = { ...user };
    await axios
      .post("http://localhost:3000/login", postUser)
      .then((response) => setPostResponse(<p>{response.data}</p>));
  };

  const handleOnSubmit = (evt) => {
    evt.preventDefault();
    handlePostUser(user);
    setUser({
      username: "",
      password: "",
    });
  };
  return (
    <div>
      <h2>Login User</h2>
      <form action="" onSubmit={handleOnSubmit}>
        <label htmlFor="username">Username: </label>
        <input
          type="text"
          name="username"
          id="username"
          value={user.username}
          onChange={handleOnChange}
        />
        <br />
        <label htmlFor="password">Password: </label>
        <input
          type="text"
          name="password"
          id="password"
          value={user.password}
          onChange={handleOnChange}
        />
        <br />
        <button>Login</button>
      </form>
      {postResponse}
      {/* <button onClick={() => navigate("/showPage", { state: { users } })}>
        Send to show page
      </button> */}
    </div>
  );
}
