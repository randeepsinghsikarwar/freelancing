import { useLocation, Link } from "react-router-dom";
export default function ShowPage() {
  const location = useLocation();
  console.log(location.state);
  const { users } = location.state;
  return (
    <div>
      <h1>Show Page</h1>
      <p>
        {users.map((u) => (
          <div key={u.id}>
            <span>{u.username}: </span>
            <span>{u.email}</span>
          </div>
        ))}
      </p>

      <Link to={"/formPage"}>
        <p>Back to form</p>
      </Link>
    </div>
  );
}
