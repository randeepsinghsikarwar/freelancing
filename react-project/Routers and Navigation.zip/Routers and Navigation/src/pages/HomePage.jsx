import { Link } from "react-router-dom";
export default function HomePage() {
  return (
    <div>
      <a href="/showPage">Show Page</a>
      <br />
      <a href="/formPage">Form Page</a>
      <br />
      <Link to={"/formPage"}>
        <button>Form</button>
      </Link>
      <Link to={"/showPage"}>
        <button>Show</button>
      </Link>
    </div>
  );
}
