import { useState } from "react";
import { useNavigate } from "react-router-dom";
export default function FormPage() {
  const navigate = useNavigate();
  const [user, setUser] = useState({
    id: "",
    username: "",
    email: "",
  });
  const [users, setUsers] = useState([]);

  const handleOnChange = (evt) => {
    const { name, value } = evt.target;
    setUser((prevUser) => {
      return { ...prevUser, id: crypto.randomUUID(), [name]: value };
    });
  };

  const addToUsers = (user) => {
    setUsers((prevUsers) => {
      return [...prevUsers, { ...user }];
    });
  };

  const handleOnSubmit = (evt) => {
    evt.preventDefault();
    addToUsers(user);
    setUser({
      id: "",
      username: "",
      email: "",
    });
  };
  return (
    <div>
      <form action="" onSubmit={handleOnSubmit}>
        <label htmlFor="username">Username: </label>
        <input
          type="text"
          name="username"
          id="username"
          value={user.username}
          onChange={handleOnChange}
        />
        <br />
        <label htmlFor="email">Email: </label>
        <input
          type="text"
          name="email"
          id="email"
          value={user.email}
          onChange={handleOnChange}
        />
        <br />
        <button>Submit</button>
      </form>

      <button onClick={() => navigate("/showPage", { state: { users } })}>
        Send to show page
      </button>
    </div>
  );
}
