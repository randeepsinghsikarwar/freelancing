export default function ContactForm({
  formData,
  handleOnChange,
  handleOnSubmit,
}) {
  return (
    <div>
      <form action="" onSubmit={handleOnSubmit}>
        <div>
          <label htmlFor="name">Name: </label>
          <input
            type="text"
            name="name"
            id="name"
            value={formData.name}
            onChange={handleOnChange}
          />
        </div>
        <div>
          <label htmlFor="email">email: </label>
          <input
            type="text"
            name="email"
            id="email"
            value={formData.email}
            onChange={handleOnChange}
          />
        </div>
        <div>
          <label htmlFor="phone">Phone: </label>
          <input
            type="text"
            name="phone"
            id="phone"
            value={formData.phone}
            onChange={handleOnChange}
          />
        </div>
        <div>
          <label htmlFor="address">Address: </label>
          <input
            type="text"
            name="address"
            id="address"
            value={formData.address}
            onChange={handleOnChange}
          />
        </div>
        <div>
          <label htmlFor="image">Image URL: </label>
          <input
            type="text"
            name="image"
            id="image"
            value={formData.image}
            onChange={handleOnChange}
          />
        </div>
        <button>Submit</button>
      </form>
    </div>
  );
}
