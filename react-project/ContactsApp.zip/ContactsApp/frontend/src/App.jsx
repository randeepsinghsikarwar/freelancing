import "./App.css";
import ContactsApp from "./ContactsApp";

function App() {
  return (
    <>
      <ContactsApp />
    </>
  );
}

export default App;
