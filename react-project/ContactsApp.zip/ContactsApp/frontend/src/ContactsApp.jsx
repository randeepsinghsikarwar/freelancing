//you need to install axios for handling the api request other than fetch

import ContactCardsContainer from "./ContactCardsContainer";
import { useState, useEffect } from "react";
import axios from "axios";
import ContactForm from "./ContactForm";

export default function ContactsApp() {
  const [contactData, setContactData] = useState([]); //to store all the data coming from the database
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    image: "",
  }); //to store the recurring data entered in the input fields
  const [postResponse, setPostResponse] = useState(""); //to store the response got from the server

  //useEffect to deal with calling and rerendering the app at the point the app receives a response from the server
  useEffect(() => {
    handleContactsDB();
  }, [postResponse]);

  //To handle get request to the server to Find the collection on the DB and setting the data need to show the cards
  const handleContactsDB = async () => {
    //axios get request from the server to fetch the data from DB
    const response = await axios.get("http://localhost:3000/contacts");
    setContactData(response.data);
  };

  //To handle the entry changes in the input fields
  const handleOnChange = (evt) => {
    const fieldName = evt.target.name;
    const fieldValue = evt.target.value;
    setFormData((prevData) => {
      return {
        ...prevData,
        [fieldName]: fieldValue,
      };
    });
  };

  //to handle the post request to the server to Save the Contact on the DB
  const handlePostContact = async (contact) => {
    const postData = {
      name: contact.name,
      email: contact.email,
      phone: contact.phone,
      address: contact.address,
      image: contact.image,
    };

    //axios post request with the server address and an endpoint URL
    await axios
      .post("http://localhost:3000/addContact", postData)
      .then((response) => setPostResponse(<p>{response.data}</p>));
  };

  //to handle the submission of the data to the post request
  const handleOnSubmit = (evt) => {
    evt.preventDefault();
    setPostResponse("");
    handlePostContact(formData);
    setFormData({
      name: "",
      email: "",
      phone: "",
      address: "",
      image: "",
    });
  };

  return (
    <div>
      <h1>Contacts App</h1>
      <ContactForm
        formData={formData} //To show if the submission was successful or not
        handleOnChange={handleOnChange}
        handleOnSubmit={handleOnSubmit}
      />
      {postResponse}
      <ContactCardsContainer contactData={contactData} />
    </div>
  );
}
