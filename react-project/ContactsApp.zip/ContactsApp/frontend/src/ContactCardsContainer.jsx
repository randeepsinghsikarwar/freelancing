import ContactCard from "./ContactCard";

export default function ContactCardsContainer({ contactData }) {
  return (
    <div>
      {contactData.map((c) => (
        <ContactCard key={c._id} data={c} />
      ))}
    </div>
  );
}
