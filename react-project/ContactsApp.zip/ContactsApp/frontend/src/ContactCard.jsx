export default function ContactCard({ data }) {
  return (
    <div className="main-card">
      <div className="card-info">
        <h2>{data.name}</h2>
        <h3>Contact Info:</h3>
        <p>email: {data.contact.email}</p>
        <p>phone: {data.contact.phone}</p>
        <p>address: {data.contact.address}</p>
      </div>
      <img src={data.image} alt="" />
    </div>
  );
}
