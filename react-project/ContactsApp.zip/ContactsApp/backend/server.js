//You need to install express, cors, and mongoose
//optional install nodemon

const express = require("express");
const server = express();
const { request, response } = require("http");
const cors = require("cors");
const mongoose = require("mongoose");
const Contact = require("./models/contact.js");

server.use(express.urlencoded({ extended: false }));
server.use(express.json());
server.use(cors()); //Need to cancel the cors security blocking getting and posting request from the same localhost

//To get you own, visit your atlas mongo db dashboard and click connect
const db_uri =
  "mongodb+srv://admin:database1234@comp1013-cluster.elf6h5d.mongodb.net/contacts?retryWrites=true&w=majority";
const port = 3000;

//Connect to the mongo DB then run the server to listen on port
mongoose
  .connect(db_uri)
  .then((result) => {
    server.listen(port, () => {
      console.log(`Listening on ${port}...\nConnected to DB`);
    });
  })
  .catch((error) => console.log(error));

//root route when the server starts
server.get("/", (request, response) => {
  response.send("LIVE!");
});

//contacts route that will get the json data from DB and prep it for the frontend to read
server.get("/contacts", async (request, response) => {
  const contactsData = await Contact.find();
  response.send(contactsData);
});

//addContact route is the post route that will add the contact data to Db
server.post("/addContact", async (request, response) => {
  const newContact = new Contact({
    name: request.body.name,
    contact: {
      email: request.body.email,
      phone: request.body.phone,
      address: request.body.address,
    },
    image: request.body.image,
  }); //Take the data in body sent from the form after submission and prep it as an object to match the schema
  const saveContact = await newContact.save();
  saveContact ? response.send("Contact added") : response.send("FAILED!!"); //if the save to DB is successful or not. This msg will be sent to frontend to be displayed.
});
