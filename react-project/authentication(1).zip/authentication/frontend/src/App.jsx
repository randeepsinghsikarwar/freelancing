import "./App.css";
// import CreateUser from "./pages/CreateUser";
import LoginUser from "./pages/LoginUser";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import PrivatePage from "./pages/PrivatePage";
import PrivateRoutes from "../utilities/PrivateRoutes";
import NotAuthorized from "./pages/NotAuthorized";

function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route element={<PrivateRoutes />}>
            <Route path="/main" element={<PrivatePage />} />
          </Route>

          <Route path="/" element={<LoginUser />} />
          <Route path="not-authorized" element={<NotAuthorized />} />
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
