export default function NotAuthorized() {
  return <p>Not authorized</p>;
}
