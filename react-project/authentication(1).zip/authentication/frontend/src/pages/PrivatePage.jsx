import Cookies from "js-cookie";
import { useNavigate, Link } from "react-router-dom";

export default function PrivatePage() {
  const navigate = useNavigate();
  const logout = () => {
    Cookies.remove("jwt-cookie");
    navigate("/");
  };
  return (
    <>
      <Link to={"/"} onClick={logout}>
        Back to login
      </Link>
      <button onClick={logout}>Logout</button>
      <h1>This is a private page</h1>
    </>
  );
}
