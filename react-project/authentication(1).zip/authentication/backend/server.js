const express = require("express");
const server = express();
const mongoose = require("mongoose");
const { request, response } = require("http");
const User = require("./models/user");
const port = 3000;
const cors = require("cors");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

server.use(express.urlencoded({ extended: false }));
server.use(express.json());
server.use(cors());

mongoose
  .connect(
    "mongodb+srv://admin:database1234@comp1013-cluster.elf6h5d.mongodb.net/products?retryWrites=true&w=majority"
  )
  .then((response) =>
    server.listen(port, () => {
      console.log(`Listening on ${port}...\nConnected to DB`);
    })
  )
  .catch((error) => console.log(error));

server.get("/", (request, response) => {
  response.send("LIVE!!!");
});

server.post("/register", async (request, response) => {
  const { username, password } = request.body;
  const postUser = new User({
    username,
  });
  postUser.password = postUser.generateHash(password);
  const saveUser = await postUser.save();
  saveUser ? response.send("User is created") : response.send("Failed!!");
});

server.post("/login", async (request, response) => {
  const { username, password } = request.body;
  const jwtToken = jwt.sign({ id: username }, "token");
  await User.findOne({ username }).then((user) => {
    if (user) {
      bcrypt.compare(password, user.password, (err, res) => {
        if (err) {
          response.send(err);
        }
        if (res) {
          response.send({ message: "Successful Login", token: jwtToken });
        } else {
          response.send({ message: "Bad authentication" });
        }
      });
    } else {
      response.send({ message: "Username does not exist" });
    }
  });
});
