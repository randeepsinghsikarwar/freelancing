const express = require("express");
const server = express();
const mongoose = require("mongoose");
const { request, response } = require("http");
const cors = require("cors");
const Movie = require("./models/movie");
const exp = require("constants");
const { resourceUsage } = require("process");

server.use(express.urlencoded({ extended: false }));
server.use(express.json());
server.use(cors());

const db_uri =
  "mongodb+srv://admin:database1234@comp1013-cluster.elf6h5d.mongodb.net/movies?retryWrites=true&w=majority";
const port = 3000;

mongoose
  .connect(db_uri)
  .then((result) => {
    server.listen(port, () => {
      console.log(`Listening on ${port}... \nConnected to DB`);
    });
  })
  .catch((error) => console.log(error));

server.get("/", (request, response) => {
  response.send("LIVE!!!");
});

server.get("/movies", async (request, response) => {
  const moviesData = await Movie.find();
  response.send(moviesData);
});

server.post("/addMovie", async (request, response) => {
  const newMovie = new Movie({
    Title: request.body.Title,
    Year: request.body.Year,
    Director: request.body.Director,
    Actors: request.body.Actors,
    Genre: request.body.Genre,
  });

  const saveMovie = await newMovie.save();
  saveMovie ? response.send("Movie added!") : response.send("Failed!");
});

server.patch("/movies/:id", async (request, response) => {
  const { id } = request.params;
  const movie = request.body;
  const patchMovie = await Movie.updateOne(
    { _id: new mongoose.Types.ObjectId(id) },
    { $set: movie }
  );
  patchMovie
    ? response.send(`${id} movie is edited`)
    : response.send("Failed to edit");
});

server.delete("/movies/:id", async (request, response) => {
  const { id } = request.params;
  const deleteMovie = await Movie.deleteOne({
    _id: new mongoose.Types.ObjectId(id),
  }); //change the id from string to object id to be used by mongoDB
  deleteMovie ? response.send("Movie Deleted") : response.send("FAILED!!");
});
