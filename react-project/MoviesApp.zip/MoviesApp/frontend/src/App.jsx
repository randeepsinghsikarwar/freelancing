import "./App.css";
import MoviesApp from "./MoviesApp";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Successful from "./pages/Successful";

function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<MoviesApp />} />
          <Route path="/successful" element={<Successful />} />
        </Routes>
      </BrowserRouter>
      {/* <MoviesApp /> */}
    </>
  );
}

export default App;
