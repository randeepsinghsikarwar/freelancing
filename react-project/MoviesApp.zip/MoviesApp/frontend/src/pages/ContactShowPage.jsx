export default function ContactShowPage() {
  return <div>SHOW ONE CONTACT</div>;
}
