import { Link } from "react-router-dom";

export default function HomePage() {
  return (
    <div>
      <h1>CONTACTS APP</h1>
      <a href="/contacts">with anchor Contacts</a>
      <br />
      <Link to="/contacts">with link Contacts</Link>
    </div>
  );
}
