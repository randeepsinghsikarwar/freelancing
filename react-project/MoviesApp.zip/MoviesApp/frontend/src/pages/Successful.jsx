export default function Successful() {
  return <h1>SUCCESSFUL!</h1>;
}
