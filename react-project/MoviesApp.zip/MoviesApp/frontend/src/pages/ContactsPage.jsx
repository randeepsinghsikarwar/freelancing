export default function ContactsPage() {
  return <div>CONTACTS</div>;
}
