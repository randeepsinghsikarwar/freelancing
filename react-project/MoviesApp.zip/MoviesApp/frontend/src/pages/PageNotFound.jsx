export default function PageNotFound() {
  return <div>PAGE NOT FOUND</div>;
}
