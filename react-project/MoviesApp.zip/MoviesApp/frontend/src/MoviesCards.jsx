import { useNavigate } from "react-router-dom";
import MovieForm from "./MovieForm";

export default function MoviesCards({
  movieGetData,
  formData,
  handleOnChange,
  handleToggleEdit,
  handleOnSubmitMovie,
  // register,
  // handleSubmit,
  // errors,
  handleMovieDelete,
  toggleEdit,
}) {
  const navigate = useNavigate();

  return (
    <div>
      <MovieForm
        movie={formData}
        handleOnChange={handleOnChange}
        handleOnSubmitMovie={handleOnSubmitMovie}
        toggleEdit={toggleEdit}
        // register={register}
        // handleSubmit={handleSubmit}
        // errors={errors}
      />
      {movieGetData.map((movie) => (
        <div key={movie._id}>
          <p>{movie.Title}</p>
          <p>{movie.Year}</p>
          <p>{movie.Director}</p>
          <p>{movie.Actors}</p>
          <p>{movie.Genre}</p>

          <button
            onClick={() => {
              handleToggleEdit(movie);
            }}
          >
            Edit
          </button>

          <button
            onClick={() => {
              handleMovieDelete(movie);
              navigate("successful");
            }}
          >
            Delete
          </button>
        </div>
      ))}
    </div>
  );
}
