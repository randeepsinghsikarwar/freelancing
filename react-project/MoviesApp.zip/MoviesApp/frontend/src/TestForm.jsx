import { useState } from "react";

export default function TestForm() {
  const [username, setUsername] = useState({
    id: "",
    username: "",
  });
  const [users, setUsers] = useState([]);

  const handleOnChange = (evt) => {
    const { name, value } = evt.target;
    setUsername((prevName) => {
      return { ...prevName, [name]: value };
    });
  };

  const addUsers = (user) => {
    setUsers((prevUsers) => {
      return [...prevUsers, { ...user, id: crypto.randomUUID() }];
    });
  };

  const handleOnSubmit = (evt) => {
    evt.preventDefault();
    addUsers(username);
    setUsername({
      id: "",
      username: "",
    });
  };

  return (
    <>
      <form action="" onSubmit={handleOnSubmit}>
        <input
          type="text"
          name="username"
          id="username"
          onChange={handleOnChange}
          value={username.username}
        />
      </form>
      <div>
        {users.map((u) => (
          <div key={u.id}>
            <p>{u.username}</p>
            <button
              onClick={() =>
                setUsername({
                  id: u.id,
                  username: u.username,
                })
              }
            >
              edit
            </button>
          </div>
        ))}
      </div>
    </>
  );
}
