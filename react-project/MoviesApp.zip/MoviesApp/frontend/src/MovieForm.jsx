import { useForm } from "react-hook-form";
import { useEffect } from "react";

export default function MovieForm({
  movie,
  handleOnChange,
  handleOnSubmitMovie,
  toggleEdit,
  // register,
  // handleSubmit,
  // errors,
}) {
  const { id } = movie;
  useEffect(() => reset(movie), [toggleEdit]);
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm({
    defaultValues: id
      ? movie
      : {
          Title: "Default",
          Year: 1200,
          Director: "Default",
          Actors: "Default",
          Genre: "Default",
        },
  });
  return (
    <div>
      <form action="" onSubmit={handleSubmit(handleOnSubmitMovie)}>
        <div>
          <label htmlFor="title">Title: </label>
          <input
            type="text"
            {...register("Title", { required: "Please enter a movie Title" })}
            id="title"
            value={movie.Title}
            onChange={handleOnChange}
          />
          <span>{errors.Title?.message}</span>
        </div>
        <div>
          <label htmlFor="year">Year </label>
          <input
            type="number"
            {...register("Year", { required: "Please enter a year" })}
            id="year"
            value={movie.Year}
            onChange={handleOnChange}
          />
          <span>{errors.Year?.message}</span>
        </div>
        <div>
          <label htmlFor="director">Director: </label>
          <input
            type="text"
            {...register("Director", {
              required: "Please enter the director's name",
            })}
            id="director"
            value={movie.Director}
            onChange={handleOnChange}
          />
          <span>{errors.Director?.message}</span>
        </div>
        <div>
          <label htmlFor="actors">Actors: </label>
          <input
            type="text"
            {...register("Actors", {
              required: "Please enter the actors' names",
            })}
            id="actors"
            value={movie.Actors}
            onChange={handleOnChange}
          />
          <span>{errors.Actors?.message}</span>
        </div>
        <div>
          <label htmlFor="genre">Genre: </label>
          <input
            type="text"
            {...register("Genre", {
              required: "Please enter the movie's genre",
            })}
            id="genre"
            value={movie.Genre}
            onChange={handleOnChange}
          />
          <span>{errors.Genre?.message}</span>
        </div>
        <button>{toggleEdit ? "Save Edit" : "Submit Movie"}</button>
      </form>
    </div>
  );
}
