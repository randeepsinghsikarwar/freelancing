export default function ContactForm({
  formData,
  handleOnChange,
  handleOnSubmit,
  handleSubmit,
  register,
  errors,
}) {
  return (
    <div>
      <form action="" onSubmit={handleSubmit(handleOnSubmit)}>
        <div>
          <label htmlFor="name">Name: </label>
          <input
            type="text"
            {...register("name", { required: "Please provide a name" })}
            id="name"
            value={formData.name}
            onChange={handleOnChange}
          />
          <p>{errors.name?.message}</p>
        </div>
        <div>
          <label htmlFor="email">email: </label>
          <input
            type="text"
            {...register("email", { required: "Please provide an email" })}
            id="email"
            value={formData.email}
            onChange={handleOnChange}
          />
          <p>{errors.email?.message}</p>
        </div>
        <div>
          <label htmlFor="phone">Phone: </label>
          <input
            type="text"
            {...register("phone", { required: "Please provide a phone" })}
            id="phone"
            value={formData.phone}
            onChange={handleOnChange}
          />
          <p>{errors.phone?.message}</p>
        </div>
        <div>
          <label htmlFor="address">Address: </label>
          <input
            type="text"
            {...register("address", { required: "Please provide an address" })}
            id="address"
            value={formData.address}
            onChange={handleOnChange}
          />
          <p>{errors.address?.message}</p>
        </div>
        <div>
          <label htmlFor="image">Image URL: </label>
          <input
            type="text"
            {...register("image", { required: "Please provide an image URL" })}
            id="image"
            value={formData.image}
            onChange={handleOnChange}
          />
          <p>{errors.image?.message}</p>
        </div>
        <button>Submit</button>
      </form>
    </div>
  );
}
