import ContactCard from "./ContactCard";

export default function ContactCardsContainer({
  contactData,
  handleContactDelete,
  handleShowForm,
  showForm,
  handleOnChange,
  handleSubmit,
  register,
  errors,
}) {
  return (
    <div>
      {contactData.map((c) => (
        <ContactCard
          key={c._id}
          data={c}
          handleContactDelete={handleContactDelete}
          handleShowForm={handleShowForm}
          showForm={showForm}
          handleOnChange={handleOnChange}
          handleSubmit={handleSubmit}
          register={register}
          errors={errors}
        />
      ))}
    </div>
  );
}
