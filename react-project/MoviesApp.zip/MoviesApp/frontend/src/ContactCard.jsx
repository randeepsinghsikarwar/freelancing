import ContactFormEdit from "./ContactFormEdit";
export default function ContactCard({
  data,
  handleContactDelete,
  handleShowForm,
  showForm,
  handleOnChange,
  handleSubmit,
  register,
  errors,
}) {
  return (
    <div className="main-card">
      <div className="card-info">
        <h2>{data.name}</h2>
        <h3>Contact Info:</h3>
        <p>email: {data.contact.email}</p>
        <p>phone: {data.contact.phone}</p>
        <p>address: {data.contact.address}</p>
      </div>
      <img src={data.image} alt="" />
      <button onClick={() => handleContactDelete(data)}>Delete</button>
      <button onClick={() => handleShowForm()}>Edit</button>
      {showForm && (
        <div>
          <ContactFormEdit
            formData={data}
            handleOnChange={handleOnChange}
            handleOnSubmit={() => {
              console.log("handle on submit");
            }}
            handleSubmit={handleSubmit}
            errors={errors}
            register={register}
          />
        </div>
      )}
    </div>
  );
}
