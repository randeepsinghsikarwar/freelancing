import { useState, useEffect } from "react";
import axios from "axios";
import MoviesCards from "./MoviesCards";
// import { useNavigate } from "react-router-dom";
// import { useForm } from "react-hook-form";

export default function MoviesApp() {
  ////////////////STATES/////////////////////////////////
  const [movieGetData, setMovieGetData] = useState([]);
  const [toggleEdit, setToggleEdit] = useState(false);
  const [formData, setFormData] = useState({
    Title: "",
    Year: "",
    Director: "",
    Actors: "",
    Genre: "",
  });
  const [postRespone, setPostResponse] = useState("");
  ///////////////EFFECTS//////////////////////////////////
  useEffect(() => {
    handleGetMovies();
    window.scrollTo(0, 0);
  }, [postRespone, toggleEdit]);
  ///////////////FORM-VALIDATION//////////////////////////

  // const {
  //   register,
  //   handleSubmit,
  //   formState: { errors },
  // } = useForm();
  //////////////HANDLERS//////////////////////////////////
  const handleGetMovies = async () => {
    const response = await axios.get("http://localhost:3000/movies");
    setMovieGetData(response.data);
  };

  const handleOnChange = (evt) => {
    const fieldName = evt.target.name;
    const fieldValue = evt.target.value;
    setFormData((prevData) => {
      return {
        ...prevData,
        [fieldName]: fieldValue,
      };
    });
  };

  const handleToggleEdit = (movie) => {
    setFormData(movie);
    setToggleEdit(true);
  };

  const handlePostMovie = async (movie) => {
    const postData = {
      Title: movie.Title,
      Year: movie.Year,
      Director: movie.Director,
      Actors: movie.Actors,
      Genre: movie.Genre,
    };

    //axios post request with the server address and an endpoint URL
    await axios
      .post("http://localhost:3000/addMovie", postData)
      .then((response) => setPostResponse(<p>{response.data}</p>));
  };

  const handleEditMovie = async (movie) => {
    const id = movie._id;
    const postData = {
      Title: movie.Title,
      Year: movie.Year,
      Director: movie.Director,
      Actors: movie.Actors,
      Genre: movie.Genre,
    };
    await axios
      .patch(`http://localhost:3000/movies/${id}`, postData)
      .then((response) => setPostResponse(<p>{response.data}</p>))
      .then(setToggleEdit(false));
  };

  //to handle the submission of the data to the post request
  const handleOnSubmitMovie = (evt) => {
    evt.preventDefault; //YOU HAVE TO REMOVE THE BRACKETS FROM HERE TO ENABLE FORM VALIDATION
    setPostResponse("");

    toggleEdit ? handleEditMovie(formData) : handlePostMovie(formData);
    setFormData({
      id: "",
      Title: "",
      Year: "",
      Director: "",
      Actors: "",
      Genre: "",
    });
  };

  const handleMovieDelete = async (movie) => {
    const id = movie._id;
    await axios
      .delete(`http://localhost:3000/movies/${id}`)
      .then((response) => setPostResponse(<p>{response.data}</p>));
  };
  ////////////////RETURN///////////////////////////////////////////
  return (
    <>
      {postRespone}
      <MoviesCards
        movieGetData={movieGetData}
        formData={formData}
        handleOnChange={handleOnChange}
        handleToggleEdit={handleToggleEdit}
        handleOnSubmitMovie={handleOnSubmitMovie}
        handleMovieDelete={handleMovieDelete}
        toggleEdit={toggleEdit}
        // register={register}
        // handleSubmit={handleSubmit}
        // errors={errors}
      />
    </>
  );
}
